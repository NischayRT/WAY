'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import { createClient } from '@/lib/supabaseClient';
import {
  analyzeCurrentPhysique,
  projectScientificDream,
  minWaistCmForBfFloor,
  estimateDefaultMeasurementsCm,
} from '@/lib/bodyProportions';
import { prefetchBodyModel } from '@/lib/bodyModels';
import { calculateTimelineAndFeasibility } from '@/lib/goalFeasibility';
import {
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Sparkles,
  Target,
  Activity,
  ArrowRight,
  Save,
} from 'lucide-react';
import { ui } from '@/lib/ui';

const BodyStudioCanvas = dynamic(() => import('./BodyStudioCanvas'), {
  ssr: false,
  loading: () => (
    <div className="flex h-72 sm:h-96 w-full items-center justify-center text-xs font-medium text-slate-400">
      Loading 3D Visualizer...
    </div>
  ),
});

const toHalfIn = (cm) => Math.round((cm / 2.54) * 2) / 2;

export default function BodyStudio({ profile }) {
  const supabase = createClient();
  const router = useRouter();
  const heightCm = Number(profile?.height_cm) || 175.0;
  const currentWeightKg = Number(profile?.weight_kg) || 75.0;
  const userSex = profile?.sex === 'female' ? 'female' : 'male';
  const [activeTab, setActiveTab] = useState('current');

  // Start downloading this user's body model (male or female file only).
  useEffect(() => {
    prefetchBodyModel(userSex);
  }, [userSex]);

  // Sex-specific starting measurements for anyone who hasn't measured yet.
  const estimates = useMemo(
    () => estimateDefaultMeasurementsCm({ heightCm, weightKg: currentWeightKg, sex: userSex }),
    [heightCm, currentWeightKg, userSex]
  );

  // Default values matching onboarding calculations
  const defaultWaistIn = useMemo(() => {
    if (profile?.waist_cm) return toHalfIn(Number(profile.waist_cm));
    return toHalfIn(estimates.waistCm);
  }, [profile?.waist_cm, estimates]);

  const defaultHipIn = useMemo(() => {
    if (profile?.hip_cm) return toHalfIn(Number(profile.hip_cm));
    return toHalfIn(estimates.hipCm);
  }, [profile?.hip_cm, estimates]);

  const defaultChestIn = useMemo(() => {
    if (profile?.chest_cm) return toHalfIn(Number(profile.chest_cm));
    return toHalfIn(estimates.chestCm);
  }, [profile?.chest_cm, estimates]);

  const defaultBicepIn = useMemo(() => {
    if (profile?.bicep_cm) return Math.round((Number(profile.bicep_cm) / 2.54) * 4) / 4;
    return Math.round((estimates.bicepCm / 2.54) * 4) / 4;
  }, [profile?.bicep_cm, estimates]);

  const [waistIn, setWaistIn] = useState(defaultWaistIn);
  const [hipIn, setHipIn] = useState(defaultHipIn);
  const [chestIn, setChestIn] = useState(defaultChestIn);
  const [bicepIn, setBicepIn] = useState(defaultBicepIn);

  useEffect(() => {
    setWaistIn(defaultWaistIn);
    setHipIn(defaultHipIn);
    setChestIn(defaultChestIn);
    setBicepIn(defaultBicepIn);
  }, [defaultWaistIn, defaultHipIn, defaultChestIn, defaultBicepIn]);

  const waistCm = waistIn * 2.54;
  const hipCm = hipIn * 2.54;
  const chestCm = chestIn * 2.54;
  const bicepCm = bicepIn * 2.54;

  const minWaistIn = useMemo(() => {
    const minCm = minWaistCmForBfFloor({
      heightCm,
      weightKg: currentWeightKg,
      chestCm,
      hipCm,
      sex: userSex,
    });
    return Math.max(26, Math.ceil((minCm / 2.54) * 2) / 2);
  }, [heightCm, currentWeightKg, chestCm, hipCm, userSex]);

  useEffect(() => {
    setWaistIn((prev) => (prev < minWaistIn ? minWaistIn : prev));
  }, [minWaistIn]);

  const currentStats = useMemo(() => {
    return analyzeCurrentPhysique({
      heightCm,
      weightKg: currentWeightKg,
      sex: userSex,
      waistCm,
      hipCm,
      chestCm,
      bicepCm,
    });
  }, [heightCm, currentWeightKg, userSex, waistCm, hipCm, chestCm, bicepCm]);

  // Target values (strictly preserved for Target Model)
  const defaultTargetWeight = useMemo(() => {
    if (profile?.dream_target_weight_kg) return Number(profile.dream_target_weight_kg);
    const idealWeight = Math.round(22.2 * (heightCm / 100) ** 2 * 10) / 10;
    return currentWeightKg > idealWeight ? idealWeight : currentWeightKg;
  }, [profile?.dream_target_weight_kg, heightCm, currentWeightKg]);

  const [targetWeight, setTargetWeight] = useState(defaultTargetWeight);
  useEffect(() => {
    if (profile?.dream_target_weight_kg) {
      setTargetWeight(Number(profile.dream_target_weight_kg));
    }
  }, [profile?.dream_target_weight_kg]);

  const [targetDate, setTargetDate] = useState(() => {
    if (profile?.dream_target_date) return String(profile.dream_target_date).slice(0, 10);
    const absDiff = Math.abs(currentWeightKg - defaultTargetWeight);
    const weeksNeeded = Math.max(1, Math.round(absDiff / 0.85));
    const d = new Date();
    d.setDate(d.getDate() + weeksNeeded * 7);
    return d.toISOString().split('T')[0];
  });

  // When a goal date was saved, keep it on first load instead of replacing it
  // with the auto-suggested one. Moving the slider afterwards re-suggests.
  const savedDateKey = useRef(
    profile?.dream_target_date ? `${defaultTargetWeight}|${currentWeightKg}` : null
  );
  useEffect(() => {
    if (savedDateKey.current === `${targetWeight}|${currentWeightKg}`) return;
    savedDateKey.current = null;
    const absDiff = Math.abs(currentWeightKg - targetWeight);
    const weeksNeeded = Math.max(1, Math.round(absDiff / 0.85));
    const d = new Date();
    d.setDate(d.getDate() + weeksNeeded * 7);
    setTargetDate(d.toISOString().split('T')[0]);
  }, [targetWeight, currentWeightKg]);

  const dreamForecast = useMemo(() => {
    const daysAvailable = Math.max(
      1,
      Math.ceil((new Date(`${targetDate}T00:00:00`) - new Date()) / (1000 * 60 * 60 * 24))
    );
    return projectScientificDream({
      currentSpecs: {
        weightKg: currentWeightKg,
        waistCm,
        hipCm,
        chestCm,
        bicepCm,
        ...currentStats,
      },
      targetWeightKg: targetWeight,
      heightCm,
      sex: userSex,
      daysAvailable,
    });
  }, [currentWeightKg, waistCm, hipCm, chestCm, bicepCm, currentStats, targetWeight, heightCm, userSex, targetDate]);

  const feasibility = useMemo(() => {
    const tdee = Math.round(currentStats.bmr * 1.5);
    return calculateTimelineAndFeasibility({
      currentWeightKg,
      targetWeightKg: targetWeight,
      targetDateStr: targetDate,
      currentBmr: currentStats.bmr,
      tdee,
      sex: userSex,
      targetBfPct: dreamForecast.targetBfPct,
    });
  }, [currentWeightKg, targetWeight, targetDate, currentStats.bmr, userSex, dreamForecast.targetBfPct]);

  // Current measurements save state
  const [savingCurrent, setSavingCurrent] = useState(false);
  const [currentSuccess, setCurrentSuccess] = useState(false);
  const [currentError, setCurrentError] = useState(null);

  // Target goal save state
  const [savingGoal, setSavingGoal] = useState(false);
  const [goalSuccess, setGoalSuccess] = useState(false);

  // Save Current Model Measurements (matching Onboarding save logic)
  const handleSaveCurrentMeasurements = async () => {
    setSavingCurrent(true);
    setCurrentError(null);

    const { error } = await supabase
      .from('profiles')
      .update({
        waist_cm: Math.round(waistCm * 10) / 10,
        hip_cm: Math.round(hipCm * 10) / 10,
        chest_cm: Math.round(chestCm * 10) / 10,
        bicep_cm: Math.round(bicepCm * 10) / 10,
      })
      .eq('id', profile.id);

    setSavingCurrent(false);
    if (error) {
      setCurrentError(error.message);
      return;
    }

    setCurrentSuccess(true);
    router.refresh();
    setTimeout(() => setCurrentSuccess(false), 3000);
  };

  const handleSetGoal = async () => {
    if (!feasibility.isFeasible) return;
    setSavingGoal(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        dream_target_weight_kg: targetWeight,
        dream_target_date: targetDate,
        override_calories: feasibility.calculatedDailyCalories,
        override_protein_g: Math.round(currentWeightKg * 2.0),
        goal: targetWeight < currentWeightKg ? 'lose_weight' : 'gain_muscle',
      })
      .eq('id', profile.id);
    setSavingGoal(false);
    if (!error) {
      setGoalSuccess(true);
      router.refresh();
      setTimeout(() => setGoalSuccess(false), 3000);
    }
  };

  const currentSliders = [
    { key: 'waist', label: 'Waist', value: waistIn, set: setWaistIn, min: minWaistIn, max: 46, step: 0.5, cm: waistCm },
    { key: 'hip', label: 'Hips', value: hipIn, set: setHipIn, min: 30, max: 50, step: 0.5, cm: hipCm },
    { key: 'chest', label: userSex === 'female' ? 'Bust' : 'Chest', value: chestIn, set: setChestIn, min: 32, max: 52, step: 0.5, cm: chestCm },
    { key: 'bicep', label: 'Arms (Biceps)', value: bicepIn, set: setBicepIn, min: 10, max: 20, step: 0.25, cm: bicepCm },
  ];

  return (
    <div className="space-y-5 max-w-2xl mx-auto pb-10 w-full px-1 sm:px-0">
      {/* 3D Visualizer Canvas Box */}
      <div className={`${ui.card} relative overflow-hidden bg-gradient-to-b from-slate-50/50 dark:from-[#071530]/60 to-white dark:to-slate-900 p-2 sm:pt-3 sm:pb-2`}>
        <BodyStudioCanvas
          currentData={{
            sex: userSex,
            heightCm,
            weightKg: currentWeightKg,
            chestCm,
            waistCm,
            hipCm,
            bicepCm,
            bodyFatPct: currentStats.bodyFatPct,
          }}
          targetData={{
            sex: userSex,
            heightCm,
            weightKg: targetWeight,
            chestCm: dreamForecast.dimensions.chestCm,
            waistCm: dreamForecast.dimensions.waistCm,
            hipCm: dreamForecast.dimensions.hipCm,
            bicepCm: dreamForecast.dimensions.bicepCm,
            bodyFatPct: dreamForecast.targetBfPct,
          }}
        />
      </div>

      {/* Tab Switcher */}
      <div className="grid grid-cols-2 rounded-xl bg-slate-200/80 dark:bg-slate-800 p-1 text-xs font-semibold text-slate-600 dark:text-slate-300">
        <button
          type="button"
          onClick={() => setActiveTab('current')}
          className={`py-2 text-center rounded-lg transition ${
            activeTab === 'current'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          1. Measurements
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('dream')}
          className={`py-2 text-center rounded-lg transition ${
            activeTab === 'dream'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          2. Your Goal
        </button>
      </div>

      <div className={ui.card}>
        {activeTab === 'current' ? (
          <div className="space-y-4 sm:space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-heading text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Sliders size={16} /> Current Measurements
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Adjust sliders to calibrate your current 3D model.
                </p>
              </div>
              <span className="self-start sm:self-auto shrink-0 text-[11px] sm:text-xs font-numeric font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg">
                {currentWeightKg} kg · {heightCm} cm
              </span>
            </div>

            {/* Responsive Onboarding-Style Measurement Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 pt-1">
              {currentSliders.map((s) => (
                <div key={s.key} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-700 dark:text-slate-300">{s.label}</span>
                    <span className="font-numeric font-bold text-emerald-600 dark:text-emerald-400">
                      {s.value}&quot; ({Math.round(s.cm)} cm)
                    </span>
                  </div>
                  <input
                    type="range"
                    min={s.min}
                    max={s.max}
                    step={s.step}
                    value={s.value}
                    onChange={(e) => s.set(Number(e.target.value))}
                    className="w-full h-2.5 sm:h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>
              ))}
            </div>

            {/* Metric Summary Badges */}
            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-900/40 p-3 sm:p-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900 dark:text-white">
                <span className="font-heading flex items-center gap-1.5">
                  <Activity size={14} className="text-emerald-500" /> Current Body Composition
                </span>
                <span className="font-numeric text-emerald-600 dark:text-emerald-400 text-sm font-extrabold">
                  {currentStats.bodyFatPct}% body fat
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 font-numeric text-center text-xs">
                <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200/70 dark:border-slate-800 shadow-2xs">
                  <span className="text-[9px] text-slate-400 block font-sans">Lean Mass</span>
                  <span className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm mt-0.5 block">
                    {currentStats.leanMassKg} kg
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200/70 dark:border-slate-800 shadow-2xs">
                  <span className="text-[9px] text-slate-400 block font-sans">BMR</span>
                  <span className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm mt-0.5 block">
                    {currentStats.bmr} kcal
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200/70 dark:border-slate-800 shadow-2xs">
                  <span className="text-[9px] text-slate-400 block font-sans">FFMI</span>
                  <span className="font-bold text-slate-800 dark:text-white text-xs sm:text-sm mt-0.5 block">
                    {currentStats.ffmi}
                  </span>
                </div>
              </div>

              {currentError && (
                <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">{currentError}</p>
              )}

              {/* Save Current Measurements Button */}
              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <button
                  type="button"
                  disabled={savingCurrent}
                  onClick={handleSaveCurrentMeasurements}
                  className={`${ui.btnPrimary} flex-1 py-2.5 cursor-pointer`}
                >
                  {savingCurrent ? (
                    'Saving...'
                  ) : currentSuccess ? (
                    <>
                      <CheckCircle2 size={15} /> Measurements Saved!
                    </>
                  ) : (
                    <>
                      <Save size={15} /> Save Measurements
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('dream')}
                  className={`${ui.btnSecondary} sm:w-auto py-2.5 cursor-pointer justify-center`}
                >
                  Configure Goal <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 sm:space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-heading text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Target size={16} className="text-emerald-500" /> Your Goal
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Set target weight and target completion date.
                </p>
              </div>
              <span className="self-start sm:self-auto shrink-0 text-[11px] sm:text-xs font-numeric font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200/60 dark:border-emerald-800 px-2.5 py-1 rounded-lg">
                ~0.85 kg / week pace
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300">Goal Weight</span>
                  <span className="font-numeric text-emerald-700 dark:text-emerald-400 font-bold text-sm">
                    {targetWeight} kg{' '}
                    <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
                      ({dreamForecast.weightDelta > 0 ? `+${dreamForecast.weightDelta}` : dreamForecast.weightDelta} kg)
                    </span>
                  </span>
                </div>
                <input
                  type="range"
                  min={Math.max(45, Math.round(currentWeightKg - 25))}
                  max={Math.round(currentWeightKg + 20)}
                  step="0.5"
                  value={targetWeight}
                  onChange={(e) => setTargetWeight(Number(e.target.value))}
                  className="w-full h-2.5 sm:h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Calendar size={13} /> By When
                  </span>
                  <span className="font-numeric text-slate-600 dark:text-slate-300 text-xs font-bold">
                    {feasibility.weeks} wks ({feasibility.days} days)
                  </span>
                </div>
                <input
                  type="date"
                  value={targetDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className={ui.input}
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-3.5 sm:p-4 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 block">
                Projected Dimensions at {targetWeight} kg
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-numeric">
                <div className="bg-white dark:bg-slate-900 p-2 sm:p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800 shadow-2xs">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Waist</span>
                  <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white block mt-0.5">
                    {dreamForecast.dimensions.waistIn}&quot;
                  </span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-semibold">
                    {(dreamForecast.dimensions.waistIn - waistIn).toFixed(1)}&quot;
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-2 sm:p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800 shadow-2xs">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Hips</span>
                  <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white block mt-0.5">
                    {dreamForecast.dimensions.hipIn}&quot;
                  </span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-semibold">
                    {(dreamForecast.dimensions.hipIn - hipIn).toFixed(1)}&quot;
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-2 sm:p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800 shadow-2xs">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">Chest</span>
                  <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white block mt-0.5">
                    {dreamForecast.dimensions.chestIn}&quot;
                  </span>
                  <span className="text-[10px] text-slate-400 block font-medium">Preserved</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-2 sm:p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800 shadow-2xs">
                  <span className="text-[10px] text-slate-400 block uppercase font-bold">V-Taper</span>
                  <span className="text-xs sm:text-sm font-bold text-emerald-600 dark:text-emerald-400 block mt-0.5">
                    {dreamForecast.dimensions.vTaper}x
                  </span>
                  <span className="text-[10px] text-slate-400 block font-medium">Ratio</span>
                </div>
              </div>
            </div>

            {feasibility.isFeasible ? (
              <div className="space-y-3 pt-1">
                <div className="rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/30 p-3.5 sm:p-4 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-heading font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
                      <Sparkles size={15} className="text-emerald-500" /> Safe Pace
                    </span>
                    <span className="font-numeric font-bold text-emerald-800 dark:text-emerald-400 text-sm">
                      {feasibility.weeklyRate} kg / wk
                    </span>
                  </div>
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 font-numeric mt-1">
                    Suggested target:{' '}
                    <strong>{feasibility.calculatedDailyCalories} kcal/day</strong> (with ~{Math.round(currentWeightKg * 2)}g protein)
                  </p>
                </div>
                <button
                  type="button"
                  disabled={savingGoal}
                  onClick={handleSetGoal}
                  className={`${ui.btnPrimary} w-full py-3 cursor-pointer`}
                >
                  {savingGoal ? (
                    'Saving...'
                  ) : goalSuccess ? (
                    <>
                      <CheckCircle2 size={16} /> Goal set!
                    </>
                  ) : (
                    <>
                      <Sparkles size={15} /> Confirm Goal
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="rounded-2xl border border-rose-200 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/40 p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-rose-100 dark:bg-rose-900 text-rose-600 dark:text-rose-300 mt-0.5">
                    <AlertTriangle size={18} />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-heading text-sm font-bold text-rose-950 dark:text-white">
                      Pace Exceeds Recommended Limit
                    </h4>
                    <p className="text-xs text-rose-800 dark:text-rose-300 leading-relaxed">
                      This timeline requires a rate beyond clinical safety recommendations.
                    </p>
                  </div>
                </div>
                <ul className="space-y-1 pl-4 list-disc text-xs text-rose-800/90 dark:text-rose-300/90 leading-normal font-numeric">
                  {feasibility.reasons.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}