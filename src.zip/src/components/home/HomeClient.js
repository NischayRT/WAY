'use client';

import { useMemo, useState, useEffect, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Scale, CheckCircle2, Target, Calendar } from 'lucide-react';
import { ui } from '@/lib/ui';
import { resolveDateTargets } from '@/lib/weightTimeline';
import WeekDateStrip from '@/components/home/WeekDateStrip';
import NutritionalOrbitPanel from '@/components/home/NutritionalOrbitPanel';
import MealTargetsCard from '@/components/home/MealTargetsCard';
import WeekMacroChart from '@/components/home/WeekMacroChart';
import RepeatMealBanner from '@/components/home/RepeatMealBanner';
import DailyLog from '@/components/home/DailyLog';
import QuickWeightLogModal from '@/components/home/QuickWeightLogModal';
import { StepsWidget, DistanceWidget, CaloriesBurnedWidget } from '@/components/home/GoogleHealthWidgets';

export default function HomeClient({
  userId,
  profile,
  weightLogs,
  todayWeighedIn,
  days,
  today,
  minDate,
  weekStart,
  weekBreakdowns,
  initialSelectedDate,
  initialTargets,
  goal,
  outOfRange,
}) {
  const router = useRouter();
  const [isNavigating, startTransition] = useTransition();
  const [selectedDate, setSelectedDate] = useState(initialSelectedDate);
  const [weightModalOpen, setWeightModalOpen] = useState(false);
  const [healthData, setHealthData] = useState({ steps: 0, distanceKm: 0, caloriesBurned: 0 });
  const [healthConnected, setHealthConnected] = useState(null);
  const [healthLoading, setHealthLoading] = useState(false);

  useEffect(() => {
    setSelectedDate(initialSelectedDate);
  }, [initialSelectedDate]);

  useEffect(() => {
    let isMounted = true;
    const ctrl = new AbortController();
    async function fetchHealthMetrics() {
      setHealthLoading(true);
      try {
        const res = await fetch(`/api/google-health/steps?date=${selectedDate}`, { signal: ctrl.signal });
        if (!res.ok) {
          if (isMounted) {
            setHealthData({ steps: 0, distanceKm: 0, caloriesBurned: 0 });
            setHealthConnected(false);
          }
          return;
        }
        const data = await res.json();
        if (isMounted) {
          if (data.connected) {
            setHealthConnected(true);
            setHealthData({
              steps: Number(data.steps) || 0,
              distanceKm: Number(data.distanceKm) || 0,
              caloriesBurned: Number(data.caloriesBurned) || 0,
            });
          } else {
            setHealthConnected(false);
            setHealthData({ steps: 0, distanceKm: 0, caloriesBurned: 0 });
          }
        }
      } catch (err) {
        if (err.name !== 'AbortError') console.error('health fetch failed', selectedDate, err);
      } finally {
        if (isMounted) setHealthLoading(false);
      }
    }
    if (selectedDate) fetchHealthMetrics();
    return () => {
      isMounted = false;
      ctrl.abort();
    };
  }, [selectedDate]);

  // Dynamically recalculate targets based on nearest weight entry to selectedDate
  const currentTargets = useMemo(() => {
    return resolveDateTargets({
      profile,
      targetDateStr: selectedDate,
      weightLogs,
    });
  }, [profile, selectedDate, weightLogs]);

  const isDateWeighedIn = useMemo(() => {
    return weightLogs.some((w) => w.logged_at === selectedDate);
  }, [weightLogs, selectedDate]);

  const handleSelectDate = (date) => {
    if (!date || date < minDate || date > today) return;

    setSelectedDate(date);
    const inCachedWeek = Object.prototype.hasOwnProperty.call(weekBreakdowns, date);
    const matchesOutOfRange = outOfRange?.date === date;

    if (inCachedWeek || matchesOutOfRange) {
      const url = date === today ? '/home' : `/home?date=${date}`;
      window.history.replaceState(null, '', url);
      return;
    }

    startTransition(() => {
      router.push(`/home?date=${date}`);
    });
  };

  const breakdown = useMemo(() => {
    if (Object.prototype.hasOwnProperty.call(weekBreakdowns, selectedDate)) {
      return weekBreakdowns[selectedDate];
    }
    if (outOfRange?.date === selectedDate) {
      return outOfRange.breakdown;
    }
    return { categories: [], overallTotals: { calories: 0, protein: 0, carbs: 0, fat: 0 } };
  }, [weekBreakdowns, outOfRange, selectedDate]);

  const { titleText, fullDateStr } = useMemo(() => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const d = new Date(year, month - 1, day);
    return {
      titleText: selectedDate === today ? 'Today' : d.toLocaleDateString('en-IN', { weekday: 'long' }),
      fullDateStr: d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
    };
  }, [selectedDate, today]);

  // Profile target attributes
  // Saved from Settings → Body Measurements → "Set goal".
  const targetWeight = profile?.dream_target_weight_kg ? Number(profile.dream_target_weight_kg) : null;
  const targetFinalDate = profile?.dream_target_date
    ? new Date(`${String(profile.dream_target_date).slice(0, 10)}T00:00:00`).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : null;

  return (
    <>
      <div className="space-y-4">
        {/* Week strip navigation */}
        <WeekDateStrip
          days={days}
          selectedDate={selectedDate}
          onSelectDate={handleSelectDate}
          today={today}
          minDate={minDate}
          userName={profile?.full_name}
        />

        <div className={`space-y-6 transition-opacity ${isNavigating ? 'opacity-60' : ''}`}>
          {/* Header Bar */}
          <div className="flex items-center justify-between pb-3 border-b-2 border-dotted dark:border-slate-700">
            <div>
              <h1 className={ui.heading}>{titleText}</h1>
              <p className="mt-0.5 text-xs text-slate-500 font-medium font-numeric">{fullDateStr}</p>
            </div>
          </div>
{/* Quick Weight & Target Banner for the selected date */}
<div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900/90 p-3.5 sm:p-4 shadow-xs">
  {/* Weight Status */}
  <div className="flex items-center gap-3 min-w-0">
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
      <Scale size={18} />
    </div>
    <div className="min-w-0 flex-1">
      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white truncate">
          Weight for {selectedDate === today ? 'Today' : fullDateStr}
        </p>
        {isDateWeighedIn && (
          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
            <CheckCircle2 size={13} className="shrink-0" /> Logged
          </span>
        )}
      </div>
      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
        Current basis:{' '}
        <strong className="font-numeric text-slate-800 dark:text-slate-200">
          {currentTargets.effectiveWeight} kg
        </strong>
        {!isDateWeighedIn && <span className="text-[10px] ml-1 opacity-75">(nearest)</span>}
      </p>
    </div>
  </div>

  {/* Target Weight & Action Buttons */}
  <div className="flex flex-wrap items-center gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800">
    {targetWeight && (
      <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-200/80 dark:border-slate-700">
        <Target size={14} className="text-emerald-500 shrink-0" />
        <div className="text-xs font-medium">
          <span className="text-slate-500 dark:text-slate-400">Target: </span>
          <strong className="font-numeric text-slate-900 dark:text-white">{targetWeight} kg</strong>
          {targetFinalDate && (
            <span className="ml-2 inline-flex items-center gap-1 text-[11px] text-slate-400 font-numeric">
              <Calendar size={11} /> {targetFinalDate}
            </span>
          )}
        </div>
      </div>
    )}

    <div className="flex items-center gap-2 w-full md:w-auto">
      <Link
        href="/settings?tab=body"
        className={`${ui.btnSecondary} flex-1 md:flex-none justify-center items-center gap-1.5 whitespace-nowrap py-2 px-3 text-xs font-semibold ${
          !targetWeight ? 'text-emerald-600 dark:text-emerald-400' : ''
        }`}
      >
        <Target size={14} />
        {targetWeight ? 'Change Target' : 'Add Target'}
      </Link>

      <button
        type="button"
        onClick={() => setWeightModalOpen(true)}
        className={`${
          isDateWeighedIn ? ui.btnSecondary : ui.btnPrimary
        } flex-1 md:flex-none justify-center whitespace-nowrap py-2 px-3.5 text-xs font-semibold`}
      >
        {isDateWeighedIn ? 'Update Weight' : 'Log Weight'}
      </button>
    </div>
  </div>
</div>

          {/* Orbit + Meal Targets + Weekly Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-stretch">
            <div className="lg:col-span-5">
              <NutritionalOrbitPanel consumed={breakdown.overallTotals} targets={currentTargets} />
            </div>
            <div className="lg:col-span-3">
              <MealTargetsCard breakdown={breakdown} targets={currentTargets} />
            </div>
            <div className="lg:col-span-4 flex flex-col gap-3">
              <div className="flex-1 min-h-[260px]">
                <WeekMacroChart
                  days={days}
                  weekBreakdowns={weekBreakdowns}
                  targetCalories={currentTargets.targetCalories}
                />
              </div>
              <RepeatMealBanner selectedDate={selectedDate} />
            </div>
          </div>

          <HealthRow
            goals={{
              steps: profile?.step_goal ?? null,
              distanceKm: profile?.distance_goal_km ? Number(profile.distance_goal_km) : null,
              burnKcal: profile?.burn_goal_kcal ?? null,
            }}
            consumed={breakdown.overallTotals}
            currentTargets={currentTargets}
            healthData={healthData}
            healthConnected={healthConnected}
            healthLoading={healthLoading}
            isToday={selectedDate === today}
          />

          <DailyLog categories={breakdown.categories} selectedDate={selectedDate} today={today} />
        </div>
      </div>

      <QuickWeightLogModal
        currentWeight={currentTargets.effectiveWeight}
        targetDate={selectedDate}
        today={today}
        isOpen={weightModalOpen}
        onClose={() => setWeightModalOpen(false)}
      />
    </>
  );
}

// Round to at most 1 decimal so float sums (e.g. 56.00000000000001) display cleanly.
const fmtG = (n) => Math.round((Number(n) || 0) * 10) / 10;

function HealthRow({ consumed, currentTargets, healthData, healthConnected, healthLoading, isToday = true, goals = {} }) {
  const remainingKcal = Math.max(0, Math.round((currentTargets.targetCalories || 0) - (consumed?.calories || 0)));
  const remainingBadge =
    remainingKcal === 0
      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300';

  const RemainingCard = (
    <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs flex flex-col justify-between min-h-[148px] sm:min-h-[154px]">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-50 dark:bg-violet-950/60 border border-violet-200/60 dark:border-violet-800/40 text-violet-600 dark:text-violet-400">
            <Target size={18} />
          </div>
          <div>
            <p className="text-[11px] font-bold uppercase tracking-widest text-slate-900 dark:text-white leading-none">Remaining</p>
            <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">{isToday ? 'Today’s budget' : 'Day’s budget'}</p>
          </div>
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-full border ${remainingBadge}`}>{remainingKcal === 0 ? 'On target' : 'Pending'}</span>
      </div>
      <div className="mt-4">
        <p className="font-numeric text-[22px] sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white">
          {remainingKcal.toLocaleString('en-IN')} <span className="text-xs font-semibold text-slate-400">kcal left</span>
        </p>
        <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
          <div className="h-full rounded-full bg-violet-500 transition-all duration-700" style={{ width: `${Math.min(100, Math.round(((consumed?.calories || 0) / Math.max(1, currentTargets.targetCalories)) * 100))}%` }} />
        </div>
        <p className="mt-1.5 text-[10px] font-semibold text-slate-400 truncate">
          Protein {fmtG(consumed?.protein)}g · Carbs {fmtG(consumed?.carbs)}g · Fat {fmtG(consumed?.fat)}g
        </p>
      </div>
    </div>
  );

  if (healthConnected === false) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-stretch">
        <div className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs flex flex-col justify-between min-h-[148px] sm:min-h-[154px]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200/60 dark:border-blue-800/40 text-blue-600 dark:text-blue-400">
              <Target size={18} />
            </div>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-widest text-slate-900 dark:text-white leading-none">Track your fitness</p>
              <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 mt-0.5">Steps · Distance · Calories burned</p>
            </div>
          </div>
          <p className="mt-3 text-xs leading-snug text-slate-500 dark:text-slate-400">Connect Google Health to see steps, distance and active calories here.</p>
          <a href="/api/google-health/connect?returnTo=%2Fhome" className="mt-3 inline-flex w-full items-center justify-center rounded-xl bg-slate-900 dark:bg-white px-4 py-2.5 text-xs font-bold text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 transition shadow-xs">
            Connect Google Health
          </a>
        </div>
        {RemainingCard}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 items-stretch">
      <StepsWidget steps={healthData.steps} targetSteps={goals.steps ?? null} loading={healthLoading} />
      <DistanceWidget distanceKm={healthData.distanceKm} targetKm={goals.distanceKm ?? null} loading={healthLoading} />
      <CaloriesBurnedWidget caloriesBurned={healthData.caloriesBurned} targetBurn={goals.burnKcal ?? null} consumedCalories={consumed?.calories ?? 0} loading={healthLoading} />
      {RemainingCard}
    </div>
  );
}