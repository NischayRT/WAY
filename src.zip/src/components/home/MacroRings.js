'use client';

import { Flame, Activity, Accessibility } from 'lucide-react';

export default function MacroRings({ consumed, targets }) {
  const proteinVal = Math.round(consumed?.protein || 0);
  const proteinTarget = targets?.proteinG || 120;

  const carbsVal = Math.round(consumed?.carbs || 0);
  const carbsTarget = targets?.carbsG || 220;

  const fatVal = Math.round(consumed?.fat || 0);
  const fatTarget = targets?.fatG || 72;

  // Geometry parameters
  const size = 180;
  const strokeWidth = 14;
  const center = size / 2;

  const outerRadius = 72;   // Outer Ring - Protein
  const middleRadius = 55;  // Middle Ring - Carbs
  const innerRadius = 38;   // Inner Ring - Fats

  const getOffset = (radius, val, target) => {
    const circumference = 2 * Math.PI * radius;
    const pct = target > 0 ? Math.min(val / target, 1) : 0;
    return circumference * (1 - pct);
  };

  const calculateIconPos = (radius, val, target) => {
    const pct = target > 0 ? Math.min(val / target, 1) : 0;
    const angleRad = (pct * 360 - 90) * (Math.PI / 180);
    return {
      x: center + radius * Math.cos(angleRad),
      y: center + radius * Math.sin(angleRad),
    };
  };

  const proteinIconPos = calculateIconPos(outerRadius, proteinVal, proteinTarget);
  const carbsIconPos = calculateIconPos(middleRadius, carbsVal, carbsTarget);
  const fatIconPos = calculateIconPos(innerRadius, fatVal, fatTarget);

  return (
    <div className="w-full bg-[#121212] rounded-3xl p-5 text-white flex items-center justify-between shadow-2xl select-none">
      {/* SVG Ring Gauge */}
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {/* Background Tracks */}
          <circle cx={center} cy={center} r={outerRadius} fill="none" stroke="#2d332d" strokeWidth={strokeWidth} />
          <circle cx={center} cy={center} r={middleRadius} fill="none" stroke="#1d2f33" strokeWidth={strokeWidth} />
          <circle cx={center} cy={center} r={innerRadius} fill="none" stroke="#331e21" strokeWidth={strokeWidth} />

          {/* Active Outer Ring - Protein */}
          <circle
            cx={center}
            cy={center}
            r={outerRadius}
            fill="none"
            stroke="#c0ed38"
            strokeWidth={strokeWidth}
            strokeDasharray={2 * Math.PI * outerRadius}
            strokeDashoffset={getOffset(outerRadius, proteinVal, proteinTarget)}
            strokeLinecap="round"
            transform={`rotate(-90 ${center} ${center})`}
            className="transition-all duration-700 ease-out"
          />

          {/* Active Middle Ring - Carbs */}
          <circle
            cx={center}
            cy={center}
            r={middleRadius}
            fill="none"
            stroke="#40e0d0"
            strokeWidth={strokeWidth}
            strokeDasharray={2 * Math.PI * middleRadius}
            strokeDashoffset={getOffset(middleRadius, carbsVal, carbsTarget)}
            strokeLinecap="round"
            transform={`rotate(-90 ${center} ${center})`}
            className="transition-all duration-700 ease-out"
          />

          {/* Active Inner Ring - Fat */}
          <circle
            cx={center}
            cy={center}
            r={innerRadius}
            fill="none"
            stroke="#ff5e62"
            strokeWidth={strokeWidth}
            strokeDasharray={2 * Math.PI * innerRadius}
            strokeDashoffset={getOffset(innerRadius, fatVal, fatTarget)}
            strokeLinecap="round"
            transform={`rotate(-90 ${center} ${center})`}
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Dynamic Tip Icons */}
        {proteinVal > 0 && (
          <div
            className="absolute flex items-center justify-center text-slate-900 pointer-events-none"
            style={{
              left: `${proteinIconPos.x}px`,
              top: `${proteinIconPos.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <Accessibility size={8} strokeWidth={3} />
          </div>
        )}

        {carbsVal > 0 && (
          <div
            className="absolute flex items-center justify-center text-slate-900 pointer-events-none"
            style={{
              left: `${carbsIconPos.x}px`,
              top: `${carbsIconPos.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <Activity size={8} strokeWidth={3} />
          </div>
        )}

        {fatVal > 0 && (
          <div
            className="absolute flex items-center justify-center text-white pointer-events-none"
            style={{
              left: `${fatIconPos.x}px`,
              top: `${fatIconPos.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <Flame size={8} strokeWidth={3} />
          </div>
        )}
      </div>

      {/* Legend & Stats */}
      <div className="flex-1 ml-6 space-y-4 font-sans">
        {/* Protein */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#c0ed38]" />
            <span className="text-base font-semibold tracking-tight text-slate-200">Protein</span>
          </div>
          <div className="font-numeric text-right">
            <span className="text-2xl font-bold text-white">{proteinVal}</span>
            <span className="text-xs font-medium text-slate-500 ml-1">/{proteinTarget}g</span>
          </div>
        </div>

        {/* Carbs */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#40e0d0]" />
            <span className="text-base font-semibold tracking-tight text-slate-200">Carbs</span>
          </div>
          <div className="font-numeric text-right">
            <span className="text-2xl font-bold text-white">{carbsVal}</span>
            <span className="text-xs font-medium text-slate-500 ml-1">/{carbsTarget}g</span>
          </div>
        </div>

        {/* Fats */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#ff5e62]" />
            <span className="text-base font-semibold tracking-tight text-slate-200">Fats</span>
          </div>
          <div className="font-numeric text-right">
            <span className="text-2xl font-bold text-white">{fatVal}</span>
            <span className="text-xs font-medium text-slate-500 ml-1">/{fatTarget}g</span>
          </div>
        </div>
      </div>
    </div>
  );
}